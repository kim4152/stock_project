package com.project.stockproject

import androidx.lifecycle.ViewModel
import com.project.stockproject.common.MyApplication

class MyViewModel : ViewModel() {
    // ConnectivityLiveData 인스턴스를 ViewModel 내에서 관리
    private val connectivityLiveData = ConnectivityLiveData(MyApplication.getAppContext())

    // 네트워크 상태를 외부에 노출
    fun getConnectivityLiveData() = connectivityLiveData
}