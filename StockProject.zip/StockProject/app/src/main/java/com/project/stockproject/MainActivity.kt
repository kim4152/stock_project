package com.project.stockproject

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.project.stockproject.common.BackKeyHandler
import com.project.stockproject.common.MyApplication
import com.project.stockproject.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        MyApplication.onCreate1(applicationContext)//전역 Context 설정
        networkChecking() //네트워크 상태 학인
        setBottomNavigation()//바텀 네비게이션
        fragmentSetting()//fragment setting




    }
    //네트워크 상태 학인
    private fun networkChecking() {
        val viewModel : MyViewModel = ViewModelProviders.of(this)[MyViewModel::class.java]
        viewModel.getConnectivityLiveData().observe(this, Observer { isConnected ->
            // 네트워크 상태에 따라 처리하는 로직
            binding.lottieLayout.isVisible = !isConnected //네트워크 연결 안되면 애니메이션 출력
        })
    }
    //바텀 네비게이션
    private fun setBottomNavigation(){
        binding.bottomNavigation.setOnItemSelectedListener { item->
            when(item.itemId) {
                R.id.item_1 -> {
                    // Respond to navigation item 1 click
                    MyApplication.makeToast("view1")
                    true
                }
                R.id.item_2 -> {
                    // Respond to navigation item 2 click
                    MyApplication.makeToast("view2")
                    true
                }
                else -> false
            }
        }
    }
    //fragment setting
    private fun fragmentSetting(){
        // Fragment를 추가하는 트랜잭션 시작
        val transaction = supportFragmentManager.beginTransaction()

        // ExampleFragment를 추가
//        val fragment = MajorIndexFragment()
//        transaction.replace(R.id.tedsf, fragment)

        // 트랜잭션 커밋
        transaction.commit()
    }
    //뒤로가기 이벤트
    private val backKeyHandler: BackKeyHandler = BackKeyHandler(this)
    @SuppressLint("MissingSuperCall")
    override fun onBackPressed() { backKeyHandler.onBackPressed() }

}